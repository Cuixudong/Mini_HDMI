#ifndef __LED_H
#define __LED_H
#include "sys.h"

#define LED_BLUE 		PAout(10)

void ledInit(void);/* LED��ʼ�� */

#endif
