HDMI-Display Firmware
=====================
Written by Hubert Kahlert (HK-Datentechnik, www.hk-datentechnik.de) for Watterott electronic (www.watterott.com).

Visit https://github.com/watterott/HDMI-Display for updates.


Installation - Compiling - Uploading
------------------------------------
  See README.md
  https://github.com/watterott/HDMI-Display/blob/master/software/README.md


License
-------
  See license.txt
  https://github.com/watterott/HDMI-Display/blob/master/software/HDMI-Display/license.txt
